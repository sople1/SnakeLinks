<?php
#Server's Response

$SLK[code] ="#--code--#";
$SLK[msg]  ="#--msg--#";
$SLK[host] ="#--host--#";
$SLK[key]  ="#--key--#";
?>