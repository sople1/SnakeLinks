<?php
#Server's Response

$SLK[code] ="404";
$SLK[msg]  ="no_response";
?>